 class Engineer extends Employee {
    public String toString(){
        String newEngineer = super.Employee("Jax",2,3, (int) (20000*1.5),3,"Engineer");
        String engineer = super.toString();

        return newEngineer + engineer + "Signing Bonus: $5K"+ "To the optimist, the glass is half full. To the pessimist, the glass is half empty. To the engineer, the glass is twice as big as it needs to be. " ;


    }

}
