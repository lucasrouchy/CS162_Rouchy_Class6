
    /**
     * Employee.java - Employee Benefits Management
     * @author Kimberly Bryant
     * @version 1
     */
    public class Employee {
        static private String name;
       static private int baseSalary;
       static private int yearsOfExperience;
        static private int yearsAtCompany;
        static private int vacationWeeks;
        private String position;
        //private String myName;


        public Employee() {
            name="";
            baseSalary=20000;
            yearsAtCompany=1;
            yearsOfExperience=1;
            position="";

        }

        /**
         * Parameterless constructor
         */


        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name=name;


        }

        public double getBaseSalary() {
            return baseSalary;
        }

        public void setBaseSalary(int salary) {

            baseSalary=salary;
        }

        public int getYearsOfExperience() {
            return yearsOfExperience;
        }

        public void setYearsOfExperience(int experience) {
            yearsOfExperience=experience;
        }

        public int getYearsAtCompany() {
            return yearsAtCompany;
        }

        public void setYearsAtCompany(int company) {

            yearsAtCompany= company;
        }

        public static int getVacationWeeks() {
            return vacationWeeks;
        }

        public static void setVacationWeeks(int vacation) {
             vacationWeeks=vacation;
        }

        public String getPosition() {
            return position;
        }

        public void setPosition(String myPosition) {
            position = position;
        }

        /**
         * Parameterless constructor
         *@Param  A variable of type TODO
         *@Param TODO A variable of type TODO
         *@Param TODO A variable of type TODO
         *@Param TODO A variable of type TODO
         */
        public String Employee(String name, int experience, int company,int salary, int vacation, String Position){

            this.name=name;
           yearsOfExperience= experience;
           yearsAtCompany= company;
           position= Position;
           vacationWeeks=vacation;
            baseSalary=salary;

            return "";
        }

        //TODO Add needed getters and setters

        /**
         * Returns the employees name, salary and motto
         * @return A value of data type String
         */
        public String toString(){
            System.out.println("is"+position);
            System.out.println("Name"+name);
            System.out.println("Their Base Salary is $"+baseSalary);
            return "";
        }

        /**
         * Returns a generic employee motto
         * @return A value of data type String
         */
        public static void main(String[]args){
            Employee writer = new TechWriter();
            System.out.println(writer.toString());
            Employee engineer = new Engineer();
            System.out.println(engineer.toString());
            Employee manager = new ProductManager();
            System.out.println(manager.toString());
        }

    }

