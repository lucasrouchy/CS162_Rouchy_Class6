class ProductManager extends Employee {
    public String toString() {
        String productManager = super.Employee("Julia", 10, 10, 20000 * 2, 4, "Product Manager");
        String manager = super.toString();


        return productManager + manager + "Shares of Company Stock: " + 100 * 10 + "There is nothing so useless as doing efficiently that which should not be done at all.";
    }

}