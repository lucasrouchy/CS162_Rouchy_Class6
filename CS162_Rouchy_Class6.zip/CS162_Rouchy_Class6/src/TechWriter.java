public class TechWriter extends Employee {

public String toString(){
    String newWriter = super.Employee("Bob",1,1,20000*1,1,"Technical Writer");
    String technical = super.toString();

    return newWriter + technical + "You can always edit a bad page. You can't edit a blank page.";

    }

}
